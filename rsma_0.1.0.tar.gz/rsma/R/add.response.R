#' Add the response variable to the dataset made of principal components
#'
#' After running PCA on a dataset with a response variable (using either select.pca
#' or select.pca.prcomp), the response variable is excluded. This function puts
#' back into the PCA dataset the response variable as the last column.
#' @param pca_data Dataset selected by PCA.
#' @param data Original dataset (before applying PCA).

add.response <- function(pca_data, data){

  p <- dim(data)[2]
  pca_p <- dim(pca_data)[2] + 1

  pca_data <- data.frame(pca_data, data[, p])
  names(pca_data)[pca_p] <- "bugs"

  return(pca_data)
}
