#' Forward stepwise regression
#'
#' This function performs a forward stepwise regression in order to reduce the
#' number of variables of a dataset. Takes a dataset, performs forward selection
#' and returns a new dataset containing only the selected variables.
#'
#' @param data Dataframe containing the data on which forward selection has to be performed
#' @param response Column index of the response variable. If not selected, the last
#' column will be selected as the response variable to perform the regressions.
#' @param type Linear or logistic regression. If the response variable is binary
#' (contains only 0 or 1), select logistic type. Default type is linear.

# Requires libraries MASS and leaps.
#
# library(MASS)
# library(leaps)

select.forward <- function(data, response, type){

  # Type is linear by default
  if(missing(type)){
    type <- "linear"
  }

  ncol <- dim(data)[2]
  # By default the response variable is the last one
  if(missing(response)){
    data <- data
    response <- dim(data)[2]
    name_response <- names(data)[response]
  }else{
    if(dim(data)[2] == response){
      data <- data
      name_response <- names(data)[response]
    }else{
      name_response <- names(data)[response]
      data <- data.frame(data[, -response], data[, response])
      names(data)[dim(data)[2]] <- name_response
    }
  }

  data_old <- data

  # Save the names
  varnames <- names(data_old)[-ncol]
  respname <- names(data_old)[ncol]

  # This is the starting model with only the response variable and the intercept
  starting.formula <- as.formula(paste(respname, "~", 1))
  empty <- lm(starting.formula, data=data_old)
  # This is the full model to define the scope of the forward selection
  full.formula <- as.formula(paste(respname, "~", paste(varnames, collapse = "+")))

  # Starting model
  if(type == "logistic"){
    starting.model <- glm(empty, data=data_old, family="binomial")
  }else{
    starting.model <- lm(empty, data=data_old)
  }

  forward.sel <- step(starting.model, scope=full.formula, direction="forward", data=data_old)

  results <- data.frame(coef(forward.sel))
  tresults <- data.frame(t(results))
  newnames <- names(tresults)[2:dim(tresults)[2]]

  data_new <- data_old[, c(newnames, respname)]
  y <- data_new

  return(y)
}


############################################

# select.forward <- function(x, position){
#   pos <- position
#   data_old <- x
#   response <- dim(data_old)[2]
#   varnames <- names(data_old)[-response]
#   respname <- names(data_old)[response]
#
#   # NB: need to change this!!! Instead of starting with full model, start with
#   # only intercept model (because it's forward stepwise regression)
#   full.formula <- as.formula(paste(respname,"~",paste(varnames,collapse="+")))
#   full.model <- lm(full.formula,data=data_old) # NB!!!!! Need to also include the logistic
#   # instead of the linear model in the situations where the response variable is just 1 or 0!
#
#   # summary(full.model)
#   # coef(full.model)
#
#   forward.sel <- step(full.model,direction="forward",data=data_old)
#   # forward.sel
#   # summary(forward.sel)
#   # coef(forward.sel)
#
#   results <- data.frame(coef(forward.sel))
#   tresults <- data.frame(t(results))
#   newnames <- names(tresults)[2:dim(tresults)[2]]
#
#   data_new <- data_old[,c(newnames,respname)]
#   y <- data_new
#
#   return(y)
# }
#
