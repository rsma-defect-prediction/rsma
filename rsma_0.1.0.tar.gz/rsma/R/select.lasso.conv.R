#' Convergence of LASSO feature selection
#'
#' This function performs LASSO a fixed number of times, in order to find convergence
#' and find the best number of features to select. Takes a dataset as input and
#' returns a new dataset containing only the selected variables.
#'
#' @param data Dataframe containing the data on which LASSO has to be performed
#' @param iterations Number of times the LASSO algorithm has to be performed. Default
#' is set to 50.

select.lasso.conv <- function(data, iterations){

  if(missing(iterations)){
    iterations <- 50
  }

  getmode <- function(v) {
    uniqv <- unique(v)
    uniqv[which.max(tabulate(match(v, uniqv)))]
  }

  num_vars <- c()

  for(i in 1 : iterations){
    current_data <- select.lasso(data)
    num_vars[i] <- dim(current_data)[2]
  }

  best <- getmode(num_vars)

  current_data <- select.lasso(data)
  current_dim <- dim(current_data)[2]
  while(current_dim != best){
    current_data <- select.lasso(data)
    current_dim <- dim(current_data)[2]
  }

  return(current_data)
}
