#' Binary transformation
#'
#' Transforms the response variable of a dataset from discrete or continuous
#' into a binary variable.
#'
#' @param data Dataframe containing the data.
#' @param response Index column of the response variable. If not selected, the
#' last column will be considered as a response variable.

binary.trans <- function(data, response){

  n <- dim(data)[1]
  p <- dim(data)[2]

  if(missing(response)){
    response <- p
  }

  for(i in 1 : n){
    if(data[i, response] > 0){
      data[i, response] <- 1
    }
    i <- i + 1
  }

  # data[, response] <- as.factor(data[, response])
  return(data)
}
