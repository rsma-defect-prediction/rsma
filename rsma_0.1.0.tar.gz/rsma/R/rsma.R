#' A package for R software metrics analysis.
#'
#' The rsma package provides two things:
#' \itemize{
#'   \item data sets containing software metrics for defect prediction
#'   \item functions to run different statistical learning algorithms over the data sets,
#'   in order to see which ones perform better for defect prediction
#' }
#'
#' @section Datasets:
#' The available data sets come from different repositories. They contain
#' metrics that come from Eclipse software (or its related plugins), NASA, Github
#' or some other source. Most of the metrics are computed from Java or C++
#' source code.
#' \cr
#' To obtain the data sets, install the following packages: \cr
#' rsma.eclipse \cr
#' rsma.github \cr
#' rsma.nasa \cr
#' rsma.quality \cr \cr
#' All the data sets available are: \cr
#' \code{\link[rsma.eclipse]{eclipse_bug}} \cr
#' \code{\link[rsma.eclipse]{eclipse_change}} \cr
#' \code{\link[rsma.eclipse]{eclipse_churn}} \cr
#' \code{\link[rsma.eclipse]{eclipse_ckoo}} \cr
#' \code{\link[rsma.eclipse]{eclipse_complexity}} \cr
#' \code{\link[rsma.eclipse]{eclipse_entropy}} \cr
#' \code{\link[rsma.eclipse]{eclipse_file}} \cr
#' \code{\link[rsma.eclipse]{eclipse_package}} \cr
#' \code{\link[rsma.github]{github_class_1.0}} \cr
#' \code{\link[rsma.github]{github_class_1.1}} \cr
#' \code{\link[rsma.github]{github_file_1.0}} \cr
#' \code{\link[rsma.github]{github_file_1.1}} \cr
#' \code{\link[rsma.nasa]{nasa_new1}} \cr
#' \code{\link[rsma.nasa]{nasa_new2}} \cr
#' \code{\link[rsma.nasa]{nasa_new3}} \cr
#' \code{\link[rsma.nasa]{nasa_new4}} \cr
#' \code{\link[rsma.nasa]{nasa_new5}} \cr
#' \code{\link[rsma.nasa]{nasa_old1}} \cr
#' \code{\link[rsma.nasa]{nasa_old2}} \cr
#' \code{\link[rsma.nasa]{nasa_old3}} \cr
#' \code{\link[rsma.quality]{quality_anonymous}} \cr
#' \code{\link[rsma.quality]{quality_class}} \cr
#' \code{\link[rsma.quality]{quality_method}} \cr
#' \code{\link[rsma.quality]{quality_package}} \cr
#'
#' @section Statistical and machine learning methods:
#' The functions available perform different algorithms for defect prediction.
#' The methods used are feature selection (to select the best variables), supervised
#' and unsupervised learning (to make the actual prediction models).
#' \cr
#' \code{\link[rsma]{select.backward}} \cr
#' \code{\link[rsma]{select.forward}} \cr
#' \code{\link[rsma]{select.lasso.conv}} \cr
#' \code{\link[rsma]{select.lasso}} \cr
#' \code{\link[rsma]{select.logistic}} \cr
#' \code{\link[rsma]{select.pca}} \cr
#' \code{\link[rsma]{spectral.clustering}} \cr
#' \code{\link[rsma]{select.pca.prcomp}} \cr
#'
#' @section Other functions:
#' Miscellaneous functions to perform different tasks along with the defect
#' prediction algorithms.
#' \cr
#' \code{\link[rsma]{add.response}} \cr
#' \code{\link[rsma]{binary.trans}} \cr
#' \code{\link[rsma]{shapiro.wilk.sample}} \cr
#'
#' @docType package
#' @name rsma
NULL




