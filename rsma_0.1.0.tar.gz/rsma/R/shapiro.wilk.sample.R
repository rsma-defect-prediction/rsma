#' Shapiro-Wilk test on a sample
#'
#' Selects a sample of a dataset and tests if each variable is normal or not.
#' Then prints the number of non-normal variables present in the dataset.
#'
#' @param data Dataframe to be studied.
#' @param size Size of the sample. Default is set to 2000 observations.
#' @param alpha Alpha threshold to run the Shapiro-Wilk test. Default is set
#' to 0.5.

shapiro.wilk.sample <- function(data, size, alpha){

  if(missing(alpha)){
    alpha <- 0.05
  } else {
    alpha <- alpha
  }

  if(missing(size)){
    sample_size <- 2000
  } else {
    sample_size <- size
  }
  data <- data
  W_statistic <- c()
  pvalue <- c()
  p <- dim(data)[2]
  n_obs <- dim(data)[1]

  if(n_obs < sample_size){
    sample_size <- n_obs
  }

  for(i in 1 : p){
    sub <- sample(data[, i], size = sample_size, replace = FALSE)
    shapiro_result <- shapiro.test(sub)
    W_statistic[i] <- shapiro_result$statistic
    pvalue[i] <- shapiro_result$p.value
  }

  print("W")
  print(W_statistic)
  print("p-values")
  print(pvalue)

  normal_variables <- 0
  for(i in 1 : p){
    if(pvalue[i] > alpha) {
      normal_variables <- normal_variables + 1
    }
  }

  print(paste0("There are ", normal_variables, " normal variables in this data set"))

}
