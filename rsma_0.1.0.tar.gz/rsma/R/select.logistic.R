#' Univariate logistic regression for variable selection
#'
#' Performs univariate logistic regression of every predictor against the response
#' variable. When the coefficient of a predictor is significantly different than
#' zero, the variable is preserved. Otherwise the variable is excluded from the model.
#' Takes a dataframe a returns a new dataframe containing only the selected variables.
#'
#' @param data Dataframe containing the data on which logistic regression has to be performed.
#' @param response Column index of the response variable. If not selected, the last
#' column will be selected as the response variable.
#' @param alpha Alpha threshold to test if the coefficient of a predictor is
#' significantly different from 0. Default alpha is set to 0.05.

select.logistic <- function(data, response, alpha){

  # The threshold is 0.05 by default
  if(missing(alpha)){
    alpha <- 0.05
  }

  ncol <- dim(data)[2]
  # By default the response variable is the last one
  if(missing(response)){
    data <- data
    response <- dim(data)[2]
    name_response <- names(data)[response]
  }else{
    if(dim(data)[2]==response){
      data <- data
      name_response <- names(data)[response]
    }else{
      name_response <- names(data)[response]
      data <- data.frame(data[, -response], data[, response])
      names(data)[dim(data)[2]] <- name_response
    }
  }

  data_old <- data

  # Save the names
  varnames <- names(data_old)[-ncol]
  respname <- names(data_old)[ncol]

  # Compute a list of pvalues. Each one is computed by fitting a logistic regression
  # with only one independent variable and the response variable. These pvalues
  # tell if the coefficient of the independent variable is significant in explaining
  # the response variable
  pvalues <- c()
  significant_vars <- c()

  for(i in 1:(ncol-1)){
    formula <- as.formula(paste(respname, "~", varnames[i]))
    mod <- glm(formula, data=data_old, family="binomial")
    pvalues[i] <- summary(mod)$coefficients[2, 4]
  }

  # if(type == "full"){
  #   formula <- as.formula(paste(respname, "~", paste(varnames,collapse = "+")))
  #   mod <- glm(formula, data=data_old, family="binomial")
  #
  #   # Questo for è da fixare
  #   for(i in 2:(ncol-1)){
  #     pval <- summary(mod)$coefficients[i,4]
  #     if(pval < alpha){
  #       var <- i-1
  #       significant_vars <- c(significant_vars,var)
  #     }
  #   }
  #   # pvalues <- as.numeric(unlist(pvalues))
  # }else{
  #   for(i in 1:(ncol-1)){
  #     formula <- as.formula(paste(respname,"~",varnames[i]))
  #     mod <- glm(formula, data=data_old, family="binomial")
  #     pvalues[i] <- summary(mod)$coefficients[2,4]
  #   }
  # }

  # Save the position of the variables for which the pvalue is significantly
  # different than 0
  significant_vars <- c()
  for(i in 1:(ncol-1)){
    if(pvalues[i] < alpha){
      significant_vars <- c(significant_vars, i)
    }
  }

  # Save the new dataset with only the significant variables and return it
  data_new <- data_old[, significant_vars]
  data_new <- data.frame(data_new, data_old[, ncol])
  names(data_new)[dim(data_new)[2]] <- respname

  return(data_new)
}

#############################

# select.logistic <- function(x, position){
#   data_old <- x
#   pos <- position # position of the response variable in the data set
#
#   # Performs univariate logistic regression on every predictor and then calculates
#   # the pvalue. If it's significantly different than zero, include it in the new
#   # data set.
#   new_data <- new_data
#   y <- new_data
#
#   return(y)
# }
