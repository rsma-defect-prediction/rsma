#' Least Absolute Shrinkage and Selection Operator
#'
#' Performs LASSO once on the dataset and returns a new dataset containing
#' the selected variables.
#'
#' @param data Dataframe containing the data on which LASSO has to be performed.
#' @param response Column index of the response variable. If not selected, the last
#' column will be selected as the response variable.
#' @param nfolds Number of folds to perform cross-validation of LASSO. Default is
#' set to 10.
#' @param seed Value of seed. Default seed is not selected.
#'
#' Requires numerical data (before running the function take out qualitative
#' variables such as name, date and so on).
#'
# NB: the last column should be the response variable!

select.lasso <- function(data, response, nfolds, seed){

  # req
  library(glmnet)

  # If the seed hasn't been selected, the function selects a random seed by default.
  # Then it sets the seed.
  if(missing(seed)){
    # NB: don't add here the option to select a random seed, because a random seed
    # is selected automatically already!!! So here I just print a message telling
    # me that the seed argument isn't there, therefore the lasso will go random
    # and will output different selections at each time!
    print("seed argument missing")
  }else{
    set.seed(seed)
  }

  # Set the selected number of folds. Default is 10.
  if(missing(nfolds)){
    nf <- 10
  }else{
    nf <- nfolds
  }

  # If the position of the response variable is not selected, then the last column
  # is considered as the response variable.
  # If the position of the response variable is selected and is different than the
  # last column, then the function moves the response variable to the end of the
  # dataset (so it can work better on it later).
  if(missing(response)){
    data <- data
    response <- dim(data)[2]
    name_response <- names(data)[response]
  }else{
    if(dim(data)[2] == response){
      data <- data
      name_response <- names(data)[response]
    }else{
      name_response <- names(data)[response]
      data <- data.frame(data[,-response], data[,response])
      names(data)[dim(data)[2]] <- name_response
    }
  }

  # First of all, standardize the data (always do that before running lasso)
  s_data_old <- data.frame(scale(data))

  # Save names of the predictors
  last <- dim(data)[2]
  varnames <- names(data)[-last]

  # Run the lasso with nfold CV:
  lasso_s_data_old <- cv.glmnet(x=as.matrix(s_data_old[varnames]), y=s_data_old[, last], grouped=FALSE, nfolds=nf)

  # Check the best model obtained
  lasso_s_data_old$nzero[which.min(sqrt(lasso_s_data_old$cvm))]
  coef(lasso_s_data_old, s=lasso_s_data_old$lambda.min)

  # Now that we have the variables selected, create a new dataset y with only these
  # variables and the response variable. The dataset y will be the output of our
  # function select.lasso()
  results <- as.matrix(coef(lasso_s_data_old, s=lasso_s_data_old$lambda.min))
  results <- data.frame(results)

  j <- 1
  p <- dim(t(results))[2]
  columns <- c()
  for(i in 2:p){
    if(results[i,1] != 0){
      columns[j] <- i - 1
      j <- j+1
    }
  }

  # Creates the new dataset with variables selected by lasso, and puts it into
  # the global environment
  # dataset_name <- deparse(substitute(data))
  # assign("lasso_data", y, envir=.GlobalEnv)

  # Resets the seed to null in case I want to spam the function
  # set.seed(NULL)

  # Returns the good dataset with only the variable selected via lasso
  y <- data[, c(columns, last)]
  return(y)
}

########################

#function1 <- function(data_old, method, response){
#  return(data_new)
#}

###########################################

# First of all: x is the original dataset (containing the predictors and the response
# variable), while y is the final dataset (containing the selected predictors and
# the response variable).

# select.lasso <- function(x, position, nfolds, seed){
#
#   # The variable resp indicates the column position of the response variable in
#   # the dataset. If there's no response variable, response=0.
#
#   # Set the number of folds for when it's time to do the cross validation
#   nf <- nfolds
#
#   # Position of the response variable in the data set (number of the column)
#   pos <- position
#
#   # Seed value to run the lasso
#   value <- seed
#   data_old <- x
#   response <- dim(data_old)[2]
#
#   set.seed(value)
#
#   # First of all, standardize the data (always do that before running lasso)
#   s_data_old <- data.frame(scale(data_old))
#
#   # Save names of the predictors
#   # if(response==0){
#   #   varnames <- names(data_old)
#   # }else varnames <- names(data_old)[-response]
#   varnames <- names(data_old)[-response]
#
#   # Run the lasso with 10-fold CV:
#   lasso_s_data_old <- cv.glmnet(x=as.matrix(s_data_old[varnames]), y=s_data_old[,response], grouped=FALSE, nfolds=nf)
#
#   # Check the best model obtained
#   lasso_s_data_old$nzero[which.min(sqrt(lasso_s_data_old$cvm))]
#   coef(lasso_s_data_old,s=lasso_s_data_old$lambda.min)
#
#   # Now that we have the variables selected, create a new dataset y with only these
#   # variables and the response variable. The dataset y will be the output of our
#   # function select.lasso()
#
#   # Haven't figured this last part out yet. Basically I want to save the results
#   # into a matrix or dataframe, then remove all the variables for which the weight
#   # is 0, and then save the names of the variables that have weights different than
#   # 0. Then I put these names into the dataset y and that's my result.
#
#
#   results <- as.matrix(coef(lasso_s_data_old,s=lasso_s_data_old$lambda.min))
#   results <- data.frame(results)
#
#   j <- 1
#   p <- dim(t(results))[2]
#   columns <- c()
#   for(i in 2:p){
#     if(results[i,1] != 0){
#       columns[j] <- i - 1
#       j <- j+1
#     }
#   }
#
#   y <- data_old[,c(columns,response)]
#   return(y)
# }

#####

# # Example:
# library(rsma)
# library(rsma.eclipse)
# library(glmnet)
#
# # For testing I'm working with eclipse_ckoo, from which I have removed the useless
# # variables (name variables and non relevant bug variables)
# eclipse_ckoo <- eclipse_ckoo[,3:20]
# response <- 18
