#' Principal components analysis
#'
#' Performs the principal components analysis on the data set. Well suited for data
#' sets where the response variable is absent (unsupervised methods).
#' Takes a dataframe, runs principal components analysis, and returns a new dataframe
#' containing only the principal components that explain a fixed percentage of
#' variability.
#'
#' @param data Dataframe containing the data on which principal components analysis has to be performed.
#' @param response Column index of the response variable. If not selected, PCA will
#' be performed on all the variables. If selected, the response variable will be
#' excluded from the PCA.
#' @param scale If FALSE, the data is not standardized. Default is set to TRUE.
#' @param variability Percentage of variability to be explained by the selected
#' principal components. Default is set to 0.95.
#' @param loadings If TRUE, instead of returning the selected dataset, returns the
#' principal components and their corresponding loadings. This is done in order to be
#' able to see how each principal component has been made. Default is set to FALSE.

# In the presence of NAs principal component analysis cannot be performed.
# Therefore it is necessary to omit the NAs in the PCA function:
# princomp(na.omit(data), cor = TRUE)
select.pca <- function(data, response, scale = c(TRUE, FALSE), variability, loadings = c(TRUE, FALSE)){

  # Clean the dataset by omitting all the NAs
  data <- na.omit(data)

  # Percentage of variability explained by the components. Default is 95%. This
  # is the threshold by which we select the number of components to use
  if(missing(variability)){
    variability <- 0.95
  }else{
    variability <- variability
  }

  # Se la response variable non è presente, allora il dataset va bene così.
  # Se c'è la response variable, allora la funzione non la considera per fare la
  # pca (e la aggiunge solo dopo alla fine!)
  if(missing(response)){
    data_old <- data
  }else{
    data_old <- data[, -response]
  }

  # Scale the dataset if the option is selected
  if(scale != FALSE){
    data_old <- scale(data_old)
  }else{
    data_old <- data_old
  }

  # Run the PCA and save the number of columns (components)
  prdata_old <- princomp(data_old)
  ncol <- dim(data_old)[2]
  variances <- c()
  explained_var <- c()

  # Compute the variance of every principal component
  for(i in 1:ncol){
    variances[i] <- summary(prdata_old)$sdev[i]^2
  }

  # Compute the pct of explained variance of every principal component
  for(i in 1:ncol){
    explained_var[i] <- variances[i]/sum(variances)
  }

  # These are all the explained variances, for every PC
  # explained_var

  # Find the number of principal components to include in our model (according
  # to the variability threshold selected, where default is 95%)
  i <- 1
  sumpct <- 0
  while(sumpct < variability){
    sumpct <- sumpct + explained_var[i]
    i <- i+1
  }
  number_comp_selected <- i-1

  # Create a new data set with only the selected components and return it
  data_new <- data.frame(summary(prdata_old)$scores[, 1:number_comp_selected])
  loadings_prdata_old <- loadings(prdata_old)
  if(missing(loadings)){
    return(data_new)
  }else{
    if(loadings == TRUE){
      loadings_prdata_old <- loadings_prdata_old[, 1:number_comp_selected]
      return(loadings_prdata_old)
    }else{
      return(data_new)
    }
  }


  # if(loadings == TRUE){
  #   loadings_prdata_old <- loadings_prdata_old[, 1:number_comp_selected]
  #   return(loadings_prdata_old)
  # }else{
  #   return(data_new)
  # }

}

# select.pca <- function(data, response, scale = c(TRUE, FALSE), variability){
#
#   # Clean the dataset by omitting all the NAs
#   data <- na.omit(data)
#
#   # Percentage of variability explained by the components. Default is 95%. This
#   # is the threshold by which we select the number of components to use
#   if(missing(variability)){
#     variability <- 0.95
#   }else{
#     variability <- variability
#   }
#
#   # Se la response variable non è presente, allora il dataset va bene così.
#   # Se c'è la response variable, allora la funzione non la considera per fare la
#   # pca (e la aggiunge solo dopo alla fine!)
#   if(missing(response)){
#     data_old <- data
#   }else{
#     data_old <- data[,-response]
#   }
#
#   # Scale the dataset if the option is selected
#   if(scale != FALSE){
#     data_old <- scale(data_old)
#   }else{
#     data_old <- data_old
#   }
#
#   # Run the PCA and save the number of columns (components)
#   prdata_old <- princomp(data_old)
#   ncol <- dim(data_old)[2]
#   variances <- c()
#   explained_var <- c()
#
#   # Compute the variance of every principal component
#   for(i in 1:ncol){
#     variances[i] <- summary(prdata_old)$sdev[i]^2
#   }
#
#   # Compute the pct of explained variance of every principal component
#   for(i in 1:ncol){
#     explained_var[i] <- variances[i]/sum(variances)
#   }
#
#   # These are all the explained variances, for every PC
#   # explained_var
#
#   # Find the number of principal components to include in our model (according
#   # to the variability threshold selected, where default is 95%)
#   i <- 1
#   sumpct <- 0
#   while(sumpct < variability){
#     sumpct <- sumpct + explained_var[i]
#     i <- i+1
#   }
#   number_comp_selected <- i-1
#
#   # Create a new data set with only the selected components and return it
#   data_new <- data.frame(summary(prdata_old)$scores[, 1:number_comp_selected])
#   return(data_new)
# }
#
#
# # select.pca <- function(x, position){
# #
# #   # Position of the response variable (if it is present in the data set). If there
# #   # is a response variable, it is excluded when doing the PCA and added only at
# #   # the end to the output data set.
# #   pos <- position
# #
# #   data_old <- x
# #   pca <- princomp(na.omit(data_old), cor=TRUE)
# #
# #   # Now need to select the components up to 95% of variability and then create
# #   # the new data set only containing these components
# #   new_data <- x
# #   y <- new_data
# #
# #   return(y)
# # }
