#' Principal components analysis (prcomp)
#'
#' Performs the principal components analysis on the data set using R function prcomp.
#' Well suited for datasets where the response variable is absent (unsupervised methods).
#' Takes a dataframe, runs principal components analysis, and returns a new dataframe
#' containing only the principal components that explain a fixed percentage of
#' variability.
#'
#' @param data Dataframe containing the data on which principal components analysis has to be performed.
#' @param response Column index of the response variable. If not selected, PCA will
#' be performed on all the variables. If selected, the response variable will be
#' excluded from the PCA.
#' @param scale If FALSE, the data is not standardized. Default is set to TRUE.
#' @param variability Percentage of variability to be explained by the selected
#' principal components. Default is set to 0.95.
#' @param loadings If TRUE, instead of returning the selected dataset, returns the
#' principal components and their corresponding loadings. This is done in order to be
#' able to see how each principal component has been made. Default is set to FALSE.


# This is modified to use prcomp instead of princomp, which works also when
# eigenvalues are negative (because it turns them to 0):
select.pca.prcomp <- function(data, response, scale = c(TRUE, FALSE), variability,
                              loadings = c(TRUE, FALSE)){

  # Clean the dataset by omitting all the NAs
  data <- na.omit(data)

  # Percentage of variability explained by the components. Default is 95%. This
  # is the threshold by which the number of components to use is selected
  if(missing(variability)){
    variability <- 0.95
  }else{
    variability <- variability
  }

  if(missing(response)){
    data_old <- data
  }else{
    data_old <- data[, -response]
  }

  # Scale the dataset if the option is selected
  if(scale != FALSE){
    data_old <- scale(data_old, center = FALSE, scale = TRUE)
  }else{
    data_old <- data_old
  }

  # Run the PCA and save the number of columns (components)
  prdata_old <- prcomp(data_old)
  ncol <- dim(data_old)[2]
  variances <- c()
  explained_var <- c()

  # Compute the variance of every principal component
  for(i in 1:ncol){
    variances[i] <- summary(prdata_old)$sdev[i]^2
  }

  # Compute the pct of explained variance of every principal component
  for(i in 1:ncol){
    explained_var[i] <- variances[i]/sum(variances)
  }

  # These are all the explained variances, for every PC
  # explained_var

  # Find the number of principal components to include in the model (according
  # to the variability threshold selected, where default is 95%)
  i <- 1
  sumpct <- 0
  while(sumpct < variability){
    sumpct <- sumpct + explained_var[i]
    i <- i+1
  }
  number_comp_selected <- i-1

  # Create a new data set with only the selected components and return it
  data_new <- data.frame(summary(prdata_old)$x[, 1:number_comp_selected])
  loadings_prdata_old <- loadings(prdata_old)
  if(missing(loadings)){
    return(data_new)
  }else{
    if(loadings == TRUE){
      loadings_prdata_old <- loadings_prdata_old[, 1:number_comp_selected]
      return(loadings_prdata_old)
    }else{
      return(data_new)
    }
  }


  # if(loadings == TRUE){
  #   loadings_prdata_old <- loadings_prdata_old[, 1:number_comp_selected]
  #   return(loadings_prdata_old)
  # }else{
  #   return(data_new)
  # }

}
