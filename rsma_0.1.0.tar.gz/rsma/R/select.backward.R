#' Backward stepwise regression
#'
#' This function performs a backwards stepwise regression in order to reduce the
#' number of variables of a dataset. Takes a dataset, performs backward selection
#' and returns a new dataset containing only the selected variables.
#'
#' @param data Dataframe containing the data on which backward selection has to be performed
#' @param response Column index of the response variable. If not selected, the last
#' column will be selected as the response variable to perform the regressions.
#' @param type Linear or logistic regression. If the response variable is binary
#' (contains only 0 or 1), select logistic type. Default type is linear.

# library(MASS)
# library(leaps)
# Libraries MASS and leaps
select.backward <- function(data, response, type){

  # Type is linear by default
  if(missing(type)){
    type <- "linear"
  }

  ncol <- dim(data)[2]
  # By default the response variable is the last one
  if(missing(response)){
    data <- data
    response <- dim(data)[2]
    name_response <- names(data)[response]
  }else{
    if(dim(data)[2] == response){
      data <- data
      name_response <- names(data)[response]
    }else{
      name_response <- names(data)[response]
      data <- data.frame(data[,-response], data[,response])
      names(data)[dim(data)[2]] <- name_response
    }
  }

  data_old <- data

  # response <- dim(data_old)[2]

  # Save the names
  varnames <- names(data_old)[-ncol]
  respname <- names(data_old)[ncol]
  full.formula <- as.formula(paste(respname, "~", paste(varnames, collapse = "+")))

  if(type == "logistic"){
    full.model <- glm(full.formula, data=data_old, family = "binomial")
  }else{
    full.model <- lm(full.formula,data=data_old)
  }

  # full.model <- lm(full.formula,data=data_old) # NB!!!!! Need to also include the logistic
  # instead of the linear model in the situations where the response variable is just 1 or 0!

  # summary(full.model)
  # coef(full.model)

  backward.sel <- step(full.model,direction="backward", data=data_old)
  # backward.sel
  # summary(backward.sel)
  # coef(backward.sel)

  results <- data.frame(coef(backward.sel))
  tresults <- data.frame(t(results))
  newnames <- names(tresults)[2:dim(tresults)[2]]

  data_new <- data_old[, c(newnames, respname)]
  y <- data_new

  return(y)
}


################################

# select.backward <- function(x, position){
#   pos <- position
#   data_old <- x
#   response <- dim(data_old)[2]
#   varnames <- names(data_old)[-response]
#   respname <- names(data_old)[response]
#   full.formula <- as.formula(paste(respname,"~",paste(varnames,collapse="+")))
#   full.model <- lm(full.formula,data=data_old) # NB!!!!! Need to also include the logistic
#   # instead of the linear model in the situations where the response variable is just 1 or 0!
#
#   # summary(full.model)
#   # coef(full.model)
#
#   backward.sel <- step(full.model,direction="backward",data=data_old)
#   # backward.sel
#   # summary(backward.sel)
#   # coef(backward.sel)
#
#   results <- data.frame(coef(backward.sel))
#   tresults <- data.frame(t(results))
#   newnames <- names(tresults)[2:dim(tresults)[2]]
#
#   data_new <- data_old[,c(newnames,respname)]
#   y <- data_new
#
#   return(y)
# }
#
#
#
#
