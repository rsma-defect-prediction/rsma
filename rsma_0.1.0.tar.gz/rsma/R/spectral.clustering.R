#' Spectral clustering
#'
#' Performs a connectivity-based clustering on the data, which splits the
#' observations into two clusters (one containing the observations with defects
#' and the other containing the clean observations). Returns a label vector,
#' describing if each observation belongs to the defective or non-defective cluster.
#'
#' @param data Dataframe on which the spectral clustering has to be performed.

spectral.clustering <- function(data) {

  # Normalize the data and build the Laplacian matrix
  norm_data <- apply(data, 2, function(x){(x - mean(x)) / sd(x)})
  W <- norm_data %*% t(norm_data)
  W[W < 0] <- 0
  W <- W - diag(diag(W))
  Dnsqrt <- diag(1 / sqrt(rowSums(W)))
  I <- diag(rep(1, nrow(W)))
  Lsym <- I - Dnsqrt %*% W %*% Dnsqrt

  # Now perform the eigendecomposition on the Laplacian matrix, and select v1
  # (the second smallest eigenvector)
  egn <- eigen(Lsym, symmetric = TRUE)
  v1 <- Dnsqrt %*% egn $ vectors[, nrow(W) - 1]
  v1 <- v1 / sqrt(sum(v1 ^ 2))

  # Divide the dataset into two clusters, and decide which one is the defective
  # cluster
  defect_proneness <- (v1 > 0)
  rs <- rowSums(norm_data)
  if (mean(rs[v1 > 0]) < mean(rs[v1 < 0])) {
    defect_proneness <- (v1 < 0)
  }

  return(defect_proneness)
}
