#' Naive Bayes results
#'
#' Performs the Naive Bayes algorithm and computes accuracy, precision, recall
#' and F1 score.
#'
#' If the response variable is binary, then the algorithm is applied directly.
#' If the response variable is discrete, then it is transformed into binary before
#' applying the algorithm.

naive.bayes.results <- function(data, response, response_type = c("binary", "discrete"), proportion, seed){

  library(klaR)
  library(e1071)
  library(caret)

  if(missing(seed)){
    print("seed argument missing")
  }else{
    set.seed(seed)
  }

  # If the response variable is not selected, by default it is the last one
  if(missing(response)){
    # Position of the response variable
    p <- dim(data)[2]
    response <- data[, p]
  }else{
    response <- data[, response]
  }

  # If response_type is "binary" then the response variable is already in the
  # required form to run the naive bayes algorithm. Otherwise if the response
  # variable is discrete, then it's going to be categorized as "0", "1" or "2+"
  if(missing(response_type)){
    response_type <- "binary"
    response <- as.factor(response)
  }else{
    response_type <- "discrete"
    n <- dim(data)[1]
    p <- dim(data)[2]
    for(i in 1 : n){
      if(data[i, p] > 0){
        data[i, p] <- "1"
      }
    }
    response <- as.factor(data[, p])
  }

  # Default train/test ratio is 0.7/0.3
  if(missing(proportion)){
    train_proportion <- 0.7
    test_proportion <- 1 - train_proportion
  }else{
    train_proportion <- proportion
    test_proportion <- 1 - train_proportion
  }

  # Split the data into train and test
  id <- sample(2, nrow(data), prob = c(train_proportion, test_proportion), replace = T)
  train <- data[id == 1, ]
  test <- data[id == 2, ]

  # Run the naive bayes algorithm
  model <- NaiveBayes(x = train[, -p], grouping = as.factor(train[, p]), usekernel=TRUE)

  # Validation of the model (find model results)
  predicted_model <- predict(model, test)
  results <- confusionMatrix(table(predicted_model$class, test[, p]))

  # The evaluation metrics vector contains: accuracy, precision, recall, F1-score
  if(ncol(data.frame(predicted_model)) > 3){
    evaluation_metrics <- c()
    evaluation_metrics[1] <- results$overall[1]
    evaluation_metrics[2] <- results$overall[1]
    evaluation_metrics[3] <- results$overall[1]
    evaluation_metrics[4] <- results$overall[1]
  }else{
    tn <- results$table[1]
    fp <- results$table[2]
    fn <- results$table[3]
    tp <- results$table[4]
    evaluation_metrics <- c()
    evaluation_metrics[1] <- (tn + tp) / (tn + fp + fn + tp)
    evaluation_metrics[2] <- tp / (tp + fp)
    evaluation_metrics[3] <- tp / (tp + fn)
    evaluation_metrics[4] <- 2 * (evaluation_metrics[2] * evaluation_metrics[3]) / (evaluation_metrics[2] + evaluation_metrics[3])
  }

  return(evaluation_metrics)
}
